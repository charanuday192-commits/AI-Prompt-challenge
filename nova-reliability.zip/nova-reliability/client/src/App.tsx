import { useEffect, useState } from 'react'

const api = (p: string, body?: any) =>
  fetch('/api' + p, body !== undefined ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined).then(r => r.json())
const inr = (n: number) => '₹' + n.toLocaleString('en-IN')
const tone = (v: number, good = 85, warn = 70) => (v >= good ? 'bg-emerald-100 text-emerald-800' : v >= warn ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800')

const Card = ({ children, cls = '' }: any) => <div className={`bg-white rounded-2xl border border-indigo-100 p-5 ${cls}`}>{children}</div>
const Pill = ({ v, children }: any) => <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${tone(v)}`}>{children}</span>
const Btn = ({ children, onClick, kind = 'primary', disabled }: any) => (
  <button disabled={disabled} onClick={onClick} className={`px-4 py-2 rounded-xl text-sm font-semibold transition active:scale-95 disabled:opacity-40 ${kind === 'primary' ? 'bg-indigo-600 text-white hover:bg-indigo-700' : kind === 'danger' ? 'bg-red-50 text-red-700 hover:bg-red-100' : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'}`}>{children}</button>
)
const Meter = ({ v, color = 'bg-indigo-600' }: any) => <div className="h-2 rounded-full bg-indigo-50 overflow-hidden"><div className={`bar h-2 rounded-full ${color}`} style={{ width: `${v}%` }} /></div>
const Kpi = ({ label, value, sub, bad }: any) => (
  <Card><div className="text-xs text-slate-500">{label}</div><div className="text-2xl font-extrabold mt-1">{value}</div><div className={`text-xs mt-1 ${bad ? 'text-red-600' : 'text-slate-500'}`}>{sub}</div></Card>
)

export default function App() {
  const [tab, setTab] = useState('home')
  const [cart, setCart] = useState<any[]>([])
  const tabs = [['home', 'Story'], ['customer', 'Customer'], ['store', 'Store'], ['admin', 'Operations']]
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 bg-indigo-950 text-white">
        <div className="max-w-6xl mx-auto px-4 py-3 flex flex-wrap items-center gap-3 justify-between">
          <div className="font-extrabold text-lg">NOVA <span className="text-indigo-300">Reliability</span></div>
          <nav className="flex gap-1">
            {tabs.map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={`px-3 py-1.5 rounded-lg text-sm font-semibold ${tab === k ? 'bg-indigo-600' : 'hover:bg-indigo-900'}`}>{l}{k === 'customer' && cart.length ? ` (${cart.length})` : ''}</button>)}
          </nav>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 py-6">
        {tab === 'home' && <Home go={setTab} />}
        {tab === 'customer' && <Customer cart={cart} setCart={setCart} />}
        {tab === 'store' && <Store />}
        {tab === 'admin' && <Admin />}
      </main>
    </div>
  )
}

function Home({ go }: any) {
  const steps = [
    ['Problem', 'Orders grew, but trust fell: cancellations 6% → 11%, repeat purchase 41% → 27%, delivery 29 → 37 min.'],
    ['Insight', '35% of cancellations come from unavailable products. Partner stores update stock only every 1–3 days.'],
    ['Solution', 'Stop promising what stores cannot deliver. Route every order to the store most likely to fulfil it.'],
    ['Product', 'Customer app with transparent confidence, a Store exception queue, and an Operations dashboard.'],
    ['AI Logic', 'Weighted score: inventory confidence, store reliability, ETA, distance and capacity, tuned by customer preference.'],
    ['Business Impact', 'Fewer failed orders → fewer tickets → better retention. Shown as a simulation, not a result.'],
  ]
  return (
    <div className="space-y-8">
      <section className="rounded-3xl bg-gradient-to-br from-indigo-700 to-violet-800 text-white p-8 md:p-12">
        <h1 className="text-3xl md:text-5xl font-extrabold leading-tight max-w-3xl">From growth at any cost to reliable local commerce</h1>
        <p className="mt-4 text-indigo-100 max-w-2xl">NOVA Reliability tells customers how likely their order is to arrive complete, and helps 620 partner stores fix only the stock records that matter.</p>
        <div className="mt-6 flex gap-3 flex-wrap"><Btn onClick={() => go('customer')}>Try the customer demo</Btn><Btn kind="soft" onClick={() => go('admin')}>See business impact</Btn></div>
      </section>
      <section className="grid md:grid-cols-3 gap-4">
        {steps.map(([t, d], i) => <Card key={t}><div className="text-xs text-indigo-600 font-semibold">Step {i + 1}</div><div className="font-bold text-lg">{t}</div><p className="text-sm text-slate-600 mt-1">{d}</p></Card>)}
      </section>
      <Card cls="bg-indigo-50"><h2 className="font-extrabold text-xl">Why NOVA Reliability?</h2>
        <p className="text-slate-700 mt-2 max-w-3xl">Quick-commerce rivals compete on discounts and speed. NOVA CART's edge is local stores with wide assortments, so its promise has to be dependable: show real availability, pick the store most likely to deliver, and substitute smartly when stock fails.</p></Card>
    </div>
  )
}

function Customer({ cart, setCart }: any) {
  const [q, setQ] = useState('Milk'), [mode, setMode] = useState('reliable'), [data, setData] = useState<any>(null)
  const [risk, setRisk] = useState<any>(null), [orders, setOrders] = useState<any[]>([]), [msg, setMsg] = useState('')
  const search = () => api(`/search?q=${encodeURIComponent(q)}&mode=${mode}`).then(setData)
  useEffect(() => { search() }, [q, mode])
  useEffect(() => { const f = () => api('/orders').then(setOrders); f(); const t = setInterval(f, 2000); return () => clearInterval(t) }, [])
  const add = (r: any) => { setCart([{ product: r.product, price: r.price, qty: 1, storeId: r.store.id, storeName: r.store.name, eta: r.eta, inv: r.inv }]); setMsg(''); }
  const simulate = async () => { const c = cart[0]; setRisk({ from: c, ...(await api('/stockout', { product: c.product, storeId: c.storeId, mode })) }); search() }
  const swap = (r: any) => { setCart([{ product: r.product, price: r.price, qty: 1, storeId: r.store.id, storeName: r.store.name, eta: r.eta, inv: r.inv }]); setRisk(null) }
  const place = async () => { const o = await api('/orders', { items: cart }); if (o.id) { setMsg(`Order ${o.id} confirmed with ${o.storeName}`); setCart([]) } }
  const modes = [['reliable', 'Most reliable'], ['fastest', 'Fastest'], ['local', 'Best local option']]
  return (
    <div className="grid lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-4">
        <div className="flex gap-2 flex-wrap">
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search milk, bread, eggs…" className="flex-1 min-w-[200px] px-4 py-2.5 rounded-xl border border-indigo-200 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
        </div>
        <div className="flex gap-2 flex-wrap">{modes.map(([k, l]) => <button key={k} onClick={() => setMode(k)} className={`px-3 py-1.5 rounded-full text-sm font-semibold ${mode === k ? 'bg-indigo-600 text-white' : 'bg-white border border-indigo-200 text-indigo-700'}`}>{l}</button>)}</div>
        {data && !data.product && <Card>No product matches "{q}". Try Milk, Bread, Eggs, Curd, Paneer, Atta or Rice.</Card>}
        {data?.results.map((r: any) => (
          <Card key={r.store.id} cls="pop">
            <div className="flex justify-between items-start gap-3 flex-wrap">
              <div>
                <div className="font-bold">{r.store.name} {r.rank === 0 && <span className="ml-1 text-xs bg-indigo-600 text-white px-2 py-0.5 rounded-full">Recommended</span>}{r.rank === 1 && <span className="ml-1 text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">Backup store</span>}</div>
                <div className="text-sm text-slate-600 mt-1">{r.product} · {inr(r.price)}</div>
                <div className="mt-2 flex gap-2 flex-wrap"><Pill v={r.inv}>{r.inv}% availability confidence</Pill><Pill v={100 - r.eta}>{r.eta} min ETA</Pill><Pill v={r.rel}>{r.rel}% store reliability</Pill></div>
                <div className="text-xs text-slate-500 mt-2">{r.dist} km away · store workload {r.load}%</div>
              </div>
              <div className="text-right"><div className="text-3xl font-extrabold text-indigo-700">{r.score}</div><div className="text-xs text-slate-500">reliability score</div><div className="mt-2"><Btn onClick={() => add(r)}>Add to cart</Btn></div></div>
            </div>
            <div className="mt-3"><Meter v={r.score} color={r.score > 80 ? 'bg-emerald-500' : r.score > 65 ? 'bg-amber-500' : 'bg-red-500'} /></div>
          </Card>
        ))}
        {data?.results.length > 0 && (
          <Card cls="overflow-x-auto"><div className="font-bold mb-2">Why this ranking? (weights for "{modes.find(m => m[0] === mode)![1]}")</div>
            <table className="w-full text-sm"><thead><tr className="text-left text-slate-500">{['Store', 'Inventory', 'Reliability', 'ETA', 'Distance', 'Capacity', 'Local'].map(h => <th key={h} className="py-1 pr-3">{h}</th>)}</tr></thead>
              <tbody><tr className="text-slate-500 text-xs"><td>weight</td>{['inv', 'rel', 'eta', 'dist', 'cap', 'local'].map(k => <td key={k}>{Math.round(data.weights[k] * 100)}%</td>)}</tr>
                {data.results.map((r: any) => <tr key={r.store.id} className="border-t border-indigo-50"><td className="py-1 pr-3 font-semibold">{r.store.name}</td>{['inv', 'rel', 'eta', 'dist', 'cap', 'local'].map(k => <td key={k}>{r.parts[k]}</td>)}</tr>)}</tbody></table></Card>
        )}
      </div>
      <div className="space-y-4">
        <Card><div className="font-bold mb-2">Your cart</div>
          {cart.length === 0 ? <p className="text-sm text-slate-500">Add a product from a recommended store to start.</p> : cart.map(c => (
            <div key={c.product} className="text-sm space-y-2"><div className="flex justify-between"><span>{c.product} × {c.qty}</span><b>{inr(c.price * c.qty)}</b></div>
              <div className="text-slate-500">{c.storeName} · {c.eta} min · {c.inv}% confidence</div>
              <div className="flex gap-2 flex-wrap"><Btn onClick={place}>Confirm order</Btn><Btn kind="danger" onClick={simulate}>Simulate stock-out</Btn><Btn kind="soft" onClick={() => setCart([])}>Clear</Btn></div></div>))}
          {msg && <div className="mt-3 text-sm bg-emerald-50 text-emerald-800 rounded-lg p-2">{msg}</div>}
        </Card>
        {risk && (
          <Card cls="pop border-amber-300 bg-amber-50"><div className="font-bold text-amber-900">{risk.from.product} just became unavailable at {risk.from.storeName}</div>
            <p className="text-sm text-amber-900/80 mb-3">Choose a fix before the order is confirmed.</p>
            {risk.altStore && <div className="bg-white rounded-xl p-3 mb-2 text-sm"><b>Same product, other store</b><div>{risk.altStore.store.name} · {risk.altStore.inv}% confidence · new ETA {risk.altStore.eta} min</div><div className="mt-2"><Btn onClick={() => swap(risk.altStore)}>Switch store</Btn></div></div>}
            {risk.substitute && <div className="bg-white rounded-xl p-3 text-sm"><b>Substitute product</b><div>{risk.substitute.product} at {risk.substitute.store.name} · {inr(risk.substitute.price)} · {risk.substitute.inv}% confidence · ETA {risk.substitute.eta} min</div><div className="mt-2"><Btn onClick={() => swap(risk.substitute)}>Accept substitute</Btn></div></div>}
            <div className="mt-2"><Btn kind="soft" onClick={() => setRisk(null)}>Dismiss</Btn></div></Card>)}
        <Card><div className="flex justify-between items-center mb-2"><b>Order tracking & history</b><button className="text-xs text-indigo-600" onClick={() => api('/reset', {}).then(() => { setCart([]); setRisk(null); search() })}>Reset demo</button></div>
          {orders.length === 0 ? <p className="text-sm text-slate-500">No orders yet.</p> : orders.map(o => (
            <div key={o.id} className="text-sm border-t border-indigo-50 py-2"><div className="flex justify-between"><b>{o.id}</b><Pill v={o.status === 'Delivered' ? 100 : 75}>{o.status}</Pill></div>
              <div className="text-slate-500">{o.items.map((i: any) => i.product).join(', ')} · {o.storeName} · {inr(o.total)} · ETA {o.eta} min · {o.conf}% confidence</div>
              <Meter v={{ Placed: 15, Packing: 45, 'Out for delivery': 75, Delivered: 100 }[o.status as string]} color="bg-emerald-500" /></div>))}
        </Card>
      </div>
    </div>
  )
}

function Store() {
  const [stores, setStores] = useState<any[]>([]), [id, setId] = useState('s1'), [d, setD] = useState<any>(null), [orders, setOrders] = useState<any[]>([])
  const load = () => { api('/store/' + id).then(setD); api('/orders?storeId=' + id).then(setOrders) }
  useEffect(() => { api('/stores').then(setStores) }, [])
  useEffect(() => { load(); const t = setInterval(load, 2000); return () => clearInterval(t) }, [id])
  const resolve = (e: any, action: string) => api(`/exceptions/${e.id}/resolve`, { action }).then(load)
  const toggle = (p: string) => api('/inventory/toggle', { storeId: id, product: p }).then(load)
  if (!d) return null
  return (
    <div className="space-y-4">
      <div className="flex gap-2 items-center flex-wrap"><b>Store</b><select value={id} onChange={e => setId(e.target.value)} className="px-3 py-2 rounded-xl border border-indigo-200 bg-white">{stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
      <div className="grid sm:grid-cols-3 gap-4">
        <Kpi label="Fulfilment score" value={d.fulfil + '%'} sub="last 30 days" />
        <Kpi label="Workload" value={d.load + '%'} sub={d.busy ? 'Busy period: new orders will be slowed' : 'Capacity available'} bad={d.busy} />
        <Kpi label="Open stock questions" value={d.exceptions.length} sub="only these need your attention" bad={d.exceptions.length > 0} />
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <Card><div className="font-bold mb-2">Inventory exception queue</div>
          {d.exceptions.length === 0 && <p className="text-sm text-slate-500">All clear. No uncertain products right now.</p>}
          {d.exceptions.map((e: any) => <div key={e.id} className="pop border-t border-indigo-50 py-3"><div className="flex justify-between"><b>{e.product}</b><Pill v={e.conf || 0}>{e.conf}% confidence</Pill></div><div className="text-xs text-slate-500 mb-2">{e.reason}</div>
            <div className="flex gap-2"><Btn onClick={() => resolve(e, 'confirm')}>Yes, in stock</Btn><Btn kind="danger" onClick={() => resolve(e, 'out')}>Out of stock</Btn></div></div>)}
        </Card>
        <Card><div className="font-bold mb-2">Today's orders</div>
          {orders.length === 0 ? <p className="text-sm text-slate-500">No orders yet. Place one from the Customer tab.</p> : orders.map(o => <div key={o.id} className="border-t border-indigo-50 py-2 text-sm flex justify-between"><span><b>{o.id}</b> · {o.items.map((i: any) => i.product).join(', ')}</span><Pill v={o.status === 'Delivered' ? 100 : 75}>{o.status}</Pill></div>)}
        </Card>
      </div>
      <Card cls="overflow-x-auto"><div className="font-bold mb-2">Manage availability</div>
        <table className="w-full text-sm"><tbody>{d.inventory.map((i: any) => <tr key={i.product} className="border-t border-indigo-50"><td className="py-2">{i.product}</td><td>{inr(i.price)}</td><td><Pill v={i.conf}>{i.inStock ? i.conf + '%' : 'Unavailable'}</Pill></td><td className="text-right"><Btn kind="soft" onClick={() => toggle(i.product)}>{i.inStock ? 'Mark unavailable' : 'Mark available'}</Btn></td></tr>)}</tbody></table></Card>
    </div>
  )
}

function Bars({ title, labels, vals, unit, color }: any) {
  const max = Math.max(...vals)
  return <Card><div className="font-bold mb-3">{title}</div><div className="flex items-end gap-2 h-32">{vals.map((v: number, i: number) => <div key={i} className="flex-1 flex flex-col items-center justify-end h-full"><span className="text-xs text-slate-500">{v}{unit}</span><div className={`w-full rounded-t-md ${color}`} style={{ height: `${(v / max) * 80}%` }} /><span className="text-xs mt-1">{labels[i]}</span></div>)}</div></Card>
}

function Admin() {
  const [m, setM] = useState<any>(null), [r, setR] = useState(60), [sort, setSort] = useState('fulfil')
  useEffect(() => { api('/metrics').then(setM) }, [])
  if (!m) return null
  const b = m.baseline, f = r / 100
  // Simulation assumptions (editable): reduces availability-driven cancellations; 1pp fewer cancellations ≈ +1.5pp repeat purchase; tickets scale with cancellations
  const cancel = +(b.cancel - b.cancel * (b.unavailShare / 100) * f).toFixed(1)
  const repeat = +(b.repeat + (b.cancel - cancel) * 1.5).toFixed(1)
  const tickets = Math.round(b.tickets * (0.55 + 0.45 * (cancel / b.cancel)))
  const saved = Math.round(b.orders * (b.cancel - cancel) / 100)
  const rows = [...m.stores].sort((a, z) => z[sort] - a[sort])
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Kpi label="Monthly orders" value={b.orders.toLocaleString('en-IN')} sub={`${m.liveOrders} placed in this demo`} />
        <Kpi label="Cancellation rate" value={b.cancel + '%'} sub="up from 6%" bad />
        <Kpi label="Repeat purchase" value={b.repeat + '%'} sub="down from 41%" bad />
        <Kpi label="Support tickets / month" value={b.tickets.toLocaleString('en-IN')} sub="up from 3,100" bad />
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Bars title="Repeat purchase %" labels={m.trend.months} vals={m.trend.repeat} unit="%" color="bg-indigo-500" />
        <Bars title="Cancellation %" labels={m.trend.months} vals={m.trend.cancel} unit="%" color="bg-red-400" />
        <Bars title="Delivery (min)" labels={m.trend.months} vals={m.trend.delivery} unit="" color="bg-amber-400" />
        <Bars title="Support tickets" labels={m.trend.months} vals={m.trend.tickets} unit="" color="bg-violet-500" />
      </div>
      <Card cls="border-2 border-indigo-300"><div className="flex justify-between flex-wrap gap-2"><h2 className="font-extrabold text-xl">Potential impact</h2><span className="text-xs bg-amber-100 text-amber-800 px-2 py-1 rounded-full font-semibold">Simulation, not actual results</span></div>
        <label className="block mt-3 text-sm">Share of availability-driven cancellations prevented: <b>{r}%</b>
          <input type="range" min="0" max="100" value={r} onChange={e => setR(+e.target.value)} className="w-full accent-indigo-600" /></label>
        <div className="grid sm:grid-cols-4 gap-3 mt-3">
          <Kpi label="Cancellation" value={cancel + '%'} sub={`from ${b.cancel}%`} />
          <Kpi label="Repeat purchase" value={repeat + '%'} sub={`from ${b.repeat}%`} />
          <Kpi label="Support tickets" value={tickets.toLocaleString('en-IN')} sub={`from ${b.tickets.toLocaleString('en-IN')}`} />
          <Kpi label="Orders recovered / month" value={saved.toLocaleString('en-IN')} sub={`≈ ${inr(saved * b.aov)} GMV`} />
        </div>
        <p className="text-xs text-slate-500 mt-3">Assumptions: 35% of cancellations are caused by unavailability; each 1-point drop in cancellations adds 1.5 points of repeat purchase; tickets fall in proportion to cancellations (45% of tickets assumed cancellation-related). Edit them in Admin() in client/src/App.tsx.</p></Card>
      <Card cls="overflow-x-auto"><div className="flex justify-between items-center mb-2"><b>Store performance</b>
        <select value={sort} onChange={e => setSort(e.target.value)} className="px-2 py-1 border border-indigo-200 rounded-lg text-sm"><option value="fulfil">Sort: fulfilment</option><option value="accuracy">Sort: inventory accuracy</option><option value="orders">Sort: orders</option></select></div>
        <table className="w-full text-sm"><thead><tr className="text-left text-slate-500"><th>Store</th><th>Orders</th><th>Fulfilment</th><th>Inventory accuracy</th><th>Avg ETA</th></tr></thead>
          <tbody>{rows.map((s: any) => <tr key={s.name} className="border-t border-indigo-50"><td className="py-2 font-semibold">{s.name}</td><td>{s.orders}</td><td><Pill v={s.fulfil}>{s.fulfil}%</Pill></td><td><Pill v={s.accuracy}>{s.accuracy}%</Pill></td><td>{s.eta} min</td></tr>)}</tbody></table></Card>
    </div>
  )
}
