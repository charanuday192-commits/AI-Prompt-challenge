import express from 'express'
import cors from 'cors'
import path from 'path'
import fs from 'fs'
import { fileURLToPath } from 'url'

const app = express()
app.use(cors(), express.json())

// ---------- Synthetic data (NOVA CART case) ----------
const stores = [
  { id: 's1', name: 'Sai Lakshmi Stores', rel: 0.94, eta: 24, dist: 1.2, load: 0.45, local: 0.9, orders: 212, fulfil: 94 },
  { id: 's2', name: 'City Fresh Mart', rel: 0.88, eta: 31, dist: 2.1, load: 0.6, local: 0.5, orders: 340, fulfil: 88 },
  { id: 's3', name: 'Local Basket', rel: 0.81, eta: 35, dist: 2.8, load: 0.35, local: 0.8, orders: 158, fulfil: 81 },
  { id: 's4', name: 'Metro Daily', rel: 0.9, eta: 28, dist: 1.8, load: 0.5, local: 0.4, orders: 275, fulfil: 90 },
]
// [product, price INR, confidence % per store s1..s4 (0 = not stocked)]
const catalogue = [
  ['Milk', 28, [96, 71, 82, 0]], ['Toned Milk', 26, [92, 85, 0, 88]], ['Curd', 35, [90, 78, 84, 80]],
  ['Bread', 40, [88, 90, 70, 86]], ['Pav', 30, [85, 0, 76, 82]], ['Eggs (6)', 54, [93, 80, 0, 91]],
  ['Paneer', 95, [84, 91, 66, 0]], ['Atta (5kg)', 245, [95, 92, 88, 94]], ['Rice (5kg)', 320, [90, 0, 85, 93]],
]
const substitutes = { Milk: ['Toned Milk', 'Curd'], 'Toned Milk': ['Milk', 'Curd'], Bread: ['Pav'], Pav: ['Bread'], Curd: ['Milk'] }
const inventory = []
const exceptions = []
const orders = []
let exSeq = 1

function seed() {
  inventory.length = 0; exceptions.length = 0; orders.length = 0; exSeq = 1
  catalogue.forEach(([product, price, confs]) =>
    confs.forEach((c, i) => c > 0 && inventory.push({ storeId: stores[i].id, product, price, conf: c, inStock: true })))
  inventory.filter(i => i.conf < 75).forEach(i => exceptions.push({
    id: exSeq++, storeId: i.storeId, product: i.product, conf: i.conf, status: 'open',
    reason: i.conf < 70 ? 'Not updated for 2+ days' : 'Stock last confirmed 36h ago',
  }))
}
seed()

// ---------- Decision engine ----------
const WEIGHTS = {
  reliable: { inv: 0.4, rel: 0.3, eta: 0.15, dist: 0.1, cap: 0.05, local: 0 },   // formula from the brief
  fastest:  { inv: 0.2, rel: 0.15, eta: 0.4, dist: 0.2, cap: 0.05, local: 0 },
  local:    { inv: 0.3, rel: 0.2, eta: 0.1, dist: 0.15, cap: 0.05, local: 0.2 },
}
const clamp = x => Math.max(0, Math.min(1, x))
const pct = x => Math.round(x * 1000) / 10

function rank(product, mode = 'reliable', exclude = []) {
  const w = WEIGHTS[mode] || WEIGHTS.reliable
  return inventory
    .filter(i => i.product === product && i.inStock && !exclude.includes(i.storeId))
    .map(i => {
      const s = stores.find(x => x.id === i.storeId)
      const p = { inv: i.conf / 100, rel: s.rel, eta: clamp(1 - (s.eta - 15) / 45), dist: clamp(1 - s.dist / 5), cap: 1 - s.load, local: s.local }
      const score = Object.keys(w).reduce((a, k) => a + w[k] * p[k], 0)
      return { store: s, product, price: i.price, inv: i.conf, rel: pct(s.rel), eta: s.eta, dist: s.dist,
               load: Math.round(s.load * 100), score: pct(score), parts: Object.fromEntries(Object.entries(p).map(([k, v]) => [k, pct(v)])) }
    })
    .sort((a, b) => b.score - a.score)
    .map((r, idx) => ({ ...r, rank: idx }))
}

app.get('/api/search', (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase()
  const mode = String(req.query.mode || 'reliable')
  const names = [...new Set(inventory.map(i => i.product))].filter(n => n.toLowerCase().includes(q))
  const product = names.find(n => n.toLowerCase() === q) || names[0]
  res.json({ suggestions: names, product: product || null, weights: WEIGHTS[mode] || WEIGHTS.reliable, results: product ? rank(product, mode) : [] })
})

// Inventory-risk event: product unavailable -> alternative store + substitute + updated ETA
app.post('/api/stockout', (req, res) => {
  const { product, storeId, mode = 'reliable' } = req.body
  const row = inventory.find(i => i.product === product && i.storeId === storeId)
  if (row) { row.inStock = false; row.conf = 0 }
  if (!exceptions.some(e => e.product === product && e.storeId === storeId && e.status === 'open'))
    exceptions.push({ id: exSeq++, storeId, product, conf: 0, status: 'open', reason: 'Picker reported item missing during an order' })
  const altStore = rank(product, mode, [storeId])[0] || null
  const subs = (substitutes[product] || []).flatMap(p => rank(p, mode))
  const substitute = subs.find(r => r.store.id === storeId) || subs.sort((a, b) => b.score - a.score)[0] || null
  res.json({ altStore, substitute })
})

app.post('/api/reset', (_req, res) => { seed(); res.json({ ok: true }) })

// ---------- Orders (status advances with time, demo-accelerated) ----------
const statusOf = o => {
  const t = (Date.now() - o.createdAt) / 1000
  return t < 8 ? 'Placed' : t < 20 ? 'Packing' : t < 35 ? 'Out for delivery' : 'Delivered'
}
app.post('/api/orders', (req, res) => {
  const { items } = req.body
  if (!items?.length) return res.status(400).json({ error: 'Cart is empty' })
  const o = { id: 'NC' + (1000 + orders.length + 1), items, total: items.reduce((a, i) => a + i.price * i.qty, 0),
    storeName: items[0].storeName, storeId: items[0].storeId, eta: Math.max(...items.map(i => i.eta)),
    conf: Math.min(...items.map(i => i.inv)), createdAt: Date.now() }
  orders.unshift(o)
  res.json(o)
})
app.get('/api/orders', (req, res) =>
  res.json(orders.filter(o => !req.query.storeId || o.storeId === req.query.storeId).map(o => ({ ...o, status: statusOf(o) }))))

// ---------- Store dashboard ----------
app.get('/api/stores', (_req, res) => res.json(stores))
app.get('/api/store/:id', (req, res) => {
  const s = stores.find(x => x.id === req.params.id)
  if (!s) return res.status(404).json({ error: 'Unknown store' })
  const live = orders.filter(o => o.storeId === s.id && statusOf(o) !== 'Delivered').length
  const load = Math.min(100, Math.round(s.load * 100 + live * 8))
  res.json({ store: s, load, busy: load > 70, fulfil: s.fulfil,
    exceptions: exceptions.filter(e => e.storeId === s.id && e.status === 'open'),
    inventory: inventory.filter(i => i.storeId === s.id) })
})
app.post('/api/exceptions/:id/resolve', (req, res) => {
  const e = exceptions.find(x => x.id === +req.params.id)
  if (!e) return res.status(404).json({ error: 'Not found' })
  const row = inventory.find(i => i.storeId === e.storeId && i.product === e.product)
  if (req.body.action === 'confirm') { row.conf = 97; row.inStock = true } else { row.conf = 0; row.inStock = false }
  e.status = 'resolved'
  res.json(e)
})
app.post('/api/inventory/toggle', (req, res) => {
  const row = inventory.find(i => i.storeId === req.body.storeId && i.product === req.body.product)
  if (!row) return res.status(404).json({ error: 'Not found' })
  row.inStock = !row.inStock; row.conf = row.inStock ? 95 : 0
  res.json(row)
})

// ---------- Admin / business analytics ----------
app.get('/api/metrics', (_req, res) => res.json({
  baseline: { users: 120000, mau: 46000, orders: 38500, aov: 486, repeat: 27, cancel: 11, delivery: 37, tickets: 5900, promo: 17, unavailShare: 35 },
  trend: { months: ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'], repeat: [41, 38, 34, 31, 29, 27], cancel: [6, 7, 8, 9, 10, 11],
           delivery: [29, 31, 33, 34, 36, 37], tickets: [3100, 3600, 4200, 4800, 5400, 5900] },
  stores: stores.map(s => ({ name: s.name, orders: s.orders, fulfil: s.fulfil, eta: s.eta, accuracy: Math.round(s.rel * 100 - 6) })),
  liveOrders: orders.length,
}))

// ---------- Serve built frontend in production ----------
const dist = path.join(path.dirname(fileURLToPath(import.meta.url)), '../client/dist')
if (fs.existsSync(dist)) { app.use(express.static(dist)); app.get('*', (_q, r) => r.sendFile(path.join(dist, 'index.html'))) }
const PORT = process.env.PORT || 4000
app.listen(PORT, () => console.log(`NOVA Reliability API on http://localhost:${PORT}`))
