# NOVA Reliability: AI-Powered Local Commerce Reliability Platform

Prototype for NOVA CART (620 local stores, 3 Indian cities). It routes each order to the store most likely to fulfil it, shows customers a transparent availability confidence, and lets stores fix only the stock records that matter.

**Stack:** React 18 + TypeScript + Vite + Tailwind (CDN) · Node.js + Express (in-memory mock data, no API keys)

## Run it
Requires Node 18+.
```bash
npm run install:all
npm run dev          # API on :4000, web on http://localhost:5173
```
Production-style: `npm start` (builds the client; Express serves it on http://localhost:4000).

## Structure
```
server/index.js        Decision engine, synthetic data, REST API
client/src/App.tsx     Story, Customer, Store and Operations views
```

## Demo flow (about 3 minutes)
1. **Story**: read Problem → Insight → Solution → Product → AI Logic → Impact.
2. **Customer**: search "Milk". Sai Lakshmi Stores (96% confidence, 24 min) is recommended; City Fresh Mart (71%) and Local Basket (82%) rank lower. Open the "Why this ranking?" table. Switch Fastest / Most reliable / Best local option.
3. Add Milk to the cart, then press **Simulate stock-out**. The system offers another store (new ETA) and a substitute (Toned Milk). Accept one, then **Confirm order**.
4. Watch **Order tracking** advance (accelerated for demo).
5. **Store** tab: the order appears; resolve the Milk exception at City Fresh Mart ("Yes, in stock" / "Out of stock"), toggle availability, see workload.
6. **Operations**: baseline KPIs and trends, store table, and the **Potential impact** slider (labelled as a simulation).

## Recommendation logic
Default ("Most reliable") score:
```
Score = 40% Inventory Confidence + 30% Store Reliability + 15% ETA Score + 10% Distance Score + 5% Capacity
ETA Score = 1 - (ETA - 15) / 45      Distance Score = 1 - km / 5      Capacity = 1 - workload
```
"Fastest" shifts weight to ETA and distance; "Best local option" adds a local-partner factor (20%). Milk scenario: Sai Lakshmi ≈ 89, City Fresh ≈ 72, Local Basket ≈ 73 (default mode). On a stock-out, the engine re-ranks excluding the failed store and searches the substitution map.

## API
`GET /api/search?q=&mode=` · `POST /api/stockout` · `POST /api/orders` · `GET /api/orders` · `GET /api/store/:id` · `POST /api/exceptions/:id/resolve` · `POST /api/inventory/toggle` · `GET /api/metrics` · `POST /api/reset`

## Data and limits
Baseline metrics come from the case. Per-store and per-product data is synthetic and stored in memory (restarts reset it). Impact numbers are **simulations based on stated assumptions**, not measured results.

## Push to GitHub
```bash
git init && git add . && git commit -m "NOVA Reliability prototype"
git branch -M main
git remote add origin https://github.com/<you>/nova-reliability.git
git push -u origin main
```
